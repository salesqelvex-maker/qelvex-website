QELVEX Global Supply Chain – Editable Website

Source package for the QELVEX website.
Public site: /
Admin: /admin

The admin panel requires Cloudflare Worker + KV + R2 bindings. See ADMIN_SETUP.txt.
