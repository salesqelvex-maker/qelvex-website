/**
 * QELVEX Global Supply Chain - editable catalogue Worker
 * Bindings required in Cloudflare:
 *   ASSETS       -> Static Assets
 *   PRODUCTS_KV  -> KV namespace
 *   IMAGES       -> R2 bucket (optional for product images)
 * Secret required:
 *   ADMIN_PASSWORD
 */
const IMAGE_MAP = {"ms-materials":"https://5.imimg.com/data5/SELLER/Default/2021/11/PY/IB/PV/47358031/is-2062-e350-c-normalised-sheet-500x500.jpg","gi-materials":"https://www.steelhollowsection.com/Content/uploads/2022805395/20221128172139b742a623828e4795a4dc1db61259d99a.jpg","ss-materials":"https://www.behaelter-kg.de/media/magefan_blog/stainless-steel-raw-materials-industrial-surface-finishes.jpg","industrial-fasteners":"https://www.snmnews.com/news/photo/202510/559880_342925_620.png","industrial-lubricants":"https://buysinopec.com/cdn/shop/articles/reddrumscover_copy_39630e9a-8fa5-44ff-a7bd-11f60afeec44.png?v=1740424630","industrial-cables":"https://news-images.dhan.co/jd-cables-limited-promoters-file-no-encumbrance-declaration-under-sebi-sast-regulations-for-fy26.jpg","industrial-machines":"https://kuzstu.ru/uploads/media/photo/2024/03/01/892dc9d55692c4e42e3e_2000x.jpg","industrial-valves":"https://flowlineoman.com/images/banner/slide1.jpg","erw-seamless-pipes":"https://huisgen.de/assets/product-stainless-steel.webp","sheet-piles-trench-sheets":"https://adayolzeminguclendirme.com/dokumanlar/hizmetler/palplans/WhatsApp%20Image%202025-05-23%20at%2012.28.42%20%281%29.jpeg","tie-rod":"https://fastform.ru/upload/iblock/597/yvm129m4ekkfdmivz4mitmn5anc5x5lc.jpg","pvc-cpvc-upvc-pipes-fittings":"https://princesystemschennai.com/images/about-us.jpg","puddle-flanges":"assets/puddle-flange.svg","centring-sheets-adjustable-props":"https://5.imimg.com/data5/SELLER/Default/2026/1/575695620/ZZ/EC/FP/869439/5-5-meter-centering-props-500x500.jpg","props-sleeves":"https://5.imimg.com/data5/SELLER/Default/2026/1/575695620/ZZ/EC/FP/869439/5-5-meter-centering-props-500x500.jpg","cement":"https://lirp.cdn-website.com/dab0e30f/dms3rep/multi/opt/3b5b397a-f0a1-4b22-bdd4-90a4c6357e8e-640w.png","tmt-bars":"https://www.heybuildex.com/_next/static/media/tmt-bars.09qbn8makqzy4.jpg","bricks-blocks":"https://frce8xp4ye4n.compat.objectstorage.eu-frankfurt-1.oraclecloud.com/blog-assets/thumbnail/44ec1c33373c948e77f738bc78272532/gazobeton-czy-pustak-ceramiczny-co-wybrac-do-budowy-domu.webp","electrical-wires-cables":"https://news-images.dhan.co/jd-cables-limited-promoters-file-no-encumbrance-declaration-under-sebi-sast-regulations-for-fy26.jpg","false-ceiling-materials":"https://image.made-in-china.com/365f3j00yDLoYHcPYWkf/False-Ceiling-Frame-Gypsum-Board-Metal-Wall-Studs-and-Tracks.webp","roofing-sheets":"https://www.zincoroof.com/assets/productshero/colored-sheets-hero.webp","pvc-wpc-mdf-panels":"https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1200&q=80"};
const DEFAULT_PRODUCTS = [
  ['ms-materials','MS Materials','Mild Steel sheets, plates, sections and related MS materials for industrial and project requirements.'],
  ['gi-materials','GI Materials','Galvanized iron materials for fabrication, roofing, structural and engineering applications.'],
  ['ss-materials','SS Materials','Stainless steel materials for industrial, fabrication and project requirements.'],
  ['industrial-fasteners','Industrial Fasteners','Bolts, nuts, washers, studs and other industrial fastening solutions.'],
  ['industrial-lubricants','Industrial Lubricants','Industrial lubricants for machinery, maintenance and engineering applications.'],
  ['industrial-cables','Industrial Cables','Industrial cables for power, control and engineering applications.'],
  ['industrial-machines','Industrial Machines','Industrial machines and equipment for engineering, fabrication and project requirements.'],
  ['industrial-valves','Industrial Valves','Industrial valves for flow-control and piping applications.'],
  ['erw-seamless-pipes','ERW / Seamless Pipes','ERW and seamless pipes for industrial, structural and piping applications.'],
  ['sheet-piles-trench-sheets','Sheet Piles / Trench Sheets','Sheet piles and trench sheets for excavation, shoring and civil engineering works.'],
  ['tie-rod','Tie Rod','Tie rods and related accessories for shuttering, formwork and construction applications.'],
  ['pvc-cpvc-upvc-pipes-fittings','PVC / CPVC / UPVC Pipes & Fittings','PVC, CPVC and UPVC pipes and fittings for plumbing and project requirements.'],
  ['puddle-flanges','Puddle Flanges','Puddle flanges for waterproof pipe penetrations and civil construction applications.'],
  ['centring-sheets-adjustable-props','Centring Sheets / Adjustable Props','Centring sheets and adjustable props for concrete formwork and construction projects.'],
  ['props-sleeves','Props Sleeves','Props sleeves and related formwork accessories for construction requirements.'],
  ['cement','Cement','Cement for residential, commercial and infrastructure construction requirements.'],
  ['tmt-bars','TMT Bars','TMT reinforcement bars for RCC and structural construction applications.'],
  ['bricks-blocks','Bricks & Blocks','AAC blocks, red clay bricks, wire cutter bricks, hollow bricks, fly ash bricks and interlock blocks.'],
  ['electrical-wires-cables','Electrical Wires & Cables','Electrical wires and cables for building, commercial and project requirements.'],
  ['false-ceiling-materials','False Ceiling Materials','False ceiling materials and accessories for commercial and interior applications.'],
  ['roofing-sheets','Roofing Sheets','Roofing sheets for industrial, commercial and building applications.'],
  ['pvc-wpc-mdf-panels','PVC / WPC / MDF Panels','PVC, WPC and MDF panels for interiors, partitions and architectural applications.']
].map(([slug,name,description],i)=>({id:slug,slug,name,description,category:i<9?'Industrial Materials':'Construction Materials',image:IMAGE_MAP[slug]||''}));

async function getProducts(env){
  const raw = await env.PRODUCTS_KV?.get('products');
  if (!raw) return DEFAULT_PRODUCTS;
  try { return JSON.parse(raw); } catch { return DEFAULT_PRODUCTS; }
}
function json(data,status=200){return new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}})}
function authorized(req,env){
  const h=req.headers.get('authorization')||'';
  return h === `Bearer ${env.ADMIN_PASSWORD}` && !!env.ADMIN_PASSWORD;
}
async function api(req,env,url){
  if(url.pathname==='/api/products' && req.method==='GET') return json(await getProducts(env));
  if(url.pathname==='/api/admin/products' && req.method==='GET') {
    if(!authorized(req,env)) return json({error:'Unauthorized'},401);
    return json(await getProducts(env));
  }
  if(url.pathname==='/api/admin/products' && req.method==='PUT') {
    if(!authorized(req,env)) return json({error:'Unauthorized'},401);
    const body=await req.json();
    if(!Array.isArray(body)) return json({error:'Products must be an array'},400);
    await env.PRODUCTS_KV.put('products',JSON.stringify(body));
    return json({ok:true,count:body.length});
  }
  if(url.pathname==='/api/admin/image' && req.method==='POST') {
    if(!authorized(req,env)) return json({error:'Unauthorized'},401);
    if(!env.IMAGES) return json({error:'IMAGES R2 binding is not configured'},503);
    const slug=(url.searchParams.get('slug')||'').replace(/[^a-z0-9-]/gi,'');
    if(!slug) return json({error:'Missing slug'},400);
    const type=req.headers.get('content-type')||'image/jpeg';
    if(!type.startsWith('image/')) return json({error:'Image only'},400);
    const ext=type.includes('png')?'png':type.includes('webp')?'webp':'jpg';
    const key=`products/${slug}.${ext}`;
    await env.IMAGES.put(key,req.body,{httpMetadata:{contentType:type}});
    return json({ok:true,key,url:`/product-image/${key}`});
  }
  if(url.pathname.startsWith('/product-image/') && req.method==='GET') {
    if(!env.IMAGES) return new Response('Image storage not configured',{status:404});
    const key=decodeURIComponent(url.pathname.slice('/product-image/'.length));
    const obj=await env.IMAGES.get(key);
    if(!obj) return new Response('Not found',{status:404});
    return new Response(obj.body,{headers:{'content-type':obj.httpMetadata?.contentType||'image/jpeg','cache-control':'public,max-age=3600'}});
  }
  return json({error:'Not found'},404);
}

export default {
  async fetch(req,env,ctx){
    const url=new URL(req.url);
    if(url.pathname.startsWith('/api/')) return api(req,env,url);
    if(url.pathname==='/admin' || url.pathname==='/admin/') return env.ASSETS.fetch(new Request(new URL('/admin/index.html',url),req));
    return env.ASSETS.fetch(req);
  }
};
